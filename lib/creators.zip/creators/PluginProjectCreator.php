<?php
declare(strict_types=1);

class PluginProjectCreator extends WordPressProjectCreator {


}
